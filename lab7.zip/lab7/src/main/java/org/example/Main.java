package org.example;
import java.util.function.*;
public class Main {
    public static void main(String[] args) {
        String inputString = "Hello World, how are you?";
        int N = 3;
        int L = 20;
        int M = 2;

        Function<String, Function<Integer, Function<Integer, String>>> processString =
                str -> n -> l -> {
                    String[] words = str.split("\\s+");
                    StringBuilder output = new StringBuilder();
                    for (int i = 0; i < n; i++) {
                        int wordCount = 0;
                        StringBuilder temp = new StringBuilder();
                        for (String word : words) {
                            if (wordCount >= M) {
                                break;
                            }
                            temp.append(word).append(", ");
                            wordCount++;
                        }
                        output.append(temp);
                    }
                    return output.toString();
                };

        String processedString = processString.apply(inputString).apply(N).apply(L);
        System.out.println(processedString);
    }
}
